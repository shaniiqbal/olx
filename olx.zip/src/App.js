import { useEffect, useState } from 'react'
import './App.css';
import Router from "./config/router";
import {auth, logout} from "./config/firebase";
import ReactDOM from 'react-dom'
import { library } from '@fortawesome/fontawesome-svg-core'
import { fab } from '@fortawesome/free-brands-svg-icons'
import { far } from '@fortawesome/free-regular-svg-icons'

library.add(fab,far)

function App() {
  const [ user, setUser ] = useState()
  const [ loading, setLoading ] = useState(true)

  useEffect(()=>{
    auth.onAuthStateChanged(function(user){
      setUser(user)
      setLoading(false)
    })
  },[])
  return (
    <div className="App">
      <header className="">
           <div style={{margin:'auto',width:'100vw'}}>
            {loading ?
            <img src="https://wpamelia.com/wp-content/uploads/2018/11/ezgif-2-6d0b072c3d3f.gif" />
            :
            <Router></Router>
            }
          </div>
      </header>
    </div>
  );
}

export default App;