import React, { useEffect, useState } from 'react'
import { useHistory,useParams } from "react-router-dom";
import { getSpecificAd } from '../../config/firebase'

function Details() {
  const history = useHistory()
  const {adId} = useParams()
  const [loading,setLoading] = useState()
  const [ adDetail, setAdDetail ] = useState({})
  useEffect(() => {
    setLoading(true)
    getSpecificAd(adId).then(res => {
      setLoading(false)
      setAdDetail(res)
    })
  }, [])
  return <div style={{ backgroundColor: 'green', width: 200 }}>
    <button onClick={() => history.goBack()}>Back</button>
    <h1>Details Page</h1>
    {loading && <img src="https://media1.giphy.com/media/3oEjI6SIIHBdRxXI40/200.gif" />}
    {!!adDetail ? <div style={{margin: 20}}>
      <img src={adDetail.image} width={200} />
      <br />
      <h2>Rs. {adDetail.price}</h2>
      <p>{adDetail.title}</p>
      <p>{adDetail.description}</p>
    </div>:""}
  </div>
}

export default Details