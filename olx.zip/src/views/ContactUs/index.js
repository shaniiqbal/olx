import React, { useState, useEffect } from 'react'
import { useHistory,useParams } from "react-router-dom";

function ContactUs() {
  const history = useHistory()
  const [loading,setLoading] = useState()

  useEffect(() => {
    setLoading(false)
  }, [])
  
  return <div style={{ backgroundColor: 'green', width: 200 }}>
    <button onClick={() => history.goBack()}>Back</button>
    <h1>Contact Us Page</h1>
    {loading && <img src="https://media1.giphy.com/media/3oEjI6SIIHBdRxXI40/200.gif" />}
  </div>
}

export default ContactUs