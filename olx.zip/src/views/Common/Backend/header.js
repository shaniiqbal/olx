import React, { useEffect, useState } from 'react'
import { useHistory } from "react-router-dom";
import { getAllAds,uploadFile } from '../../config/firebase'

function Dashboard() {
  const [ ads, setAds ] = useState([])
  const [ loading, setLoading ] = useState(false)
  const history = useHistory()
  useEffect(() => {
    setLoading(true)
    getAllAds().then(res => {
      setLoading(false)
      setAds(res)
    })
  }, [])
  return <div style={{ backgroundColor: 'red',margin: 'auto',cursor: 'pointer' }}>
    <h1>Dashboard Page</h1>
    {loading && <img src="https://media1.giphy.com/media/3oEjI6SIIHBdRxXI40/200.gif" />}
    <div>
      {ads.map(item => {
        return <div onClick={() => history.push(`/dashboard/details/${item.id}`)} style={{margin: 20}}>
          <img src={item.image} width='200'/>
          <br />
          <h2>Rs. {item.price}</h2>
          <p>{item.title}</p>
          <hr />
        </div>
      })}
    </div>
  </div>
}

export default Dashboard