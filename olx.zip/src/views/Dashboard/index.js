import React, { useEffect, useState } from 'react'
import { useHistory } from "react-router-dom";
import { getAllAds,uploadFile } from '../../config/firebase'
import { allAds } from "../../components/Ads/getallAds";
function Dashboard() {
  return <div style={{ backgroundColor: 'red',margin: 'auto',cursor: 'pointer' }}>
    <h1>Dashboard Page</h1>
    <div>
      <allAds />
    </div>
  </div>
}

export default Dashboard