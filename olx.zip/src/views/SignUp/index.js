import React, { useState } from 'react'
import { register, addUserToDb } from '../../config/firebase'
import "../Login/index.css";
import { cipher } from "../../utilities/stringHelpers";
export default function Signup() {
  const [fullName, setFullName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [password, setPassword] = useState('')
  
  const onSignup = () => {
    register(email, password).then(res => {
      console.log(res);
      addUserToDb({ fullName, email, phone, password }).then(res => {
        alert(`Email "${email}" has been successfully registered!`)
        resetFields();
      }).catch(e => {
        alert(e.message)
      })
    }).catch(e => {
      alert(e.message)
    })
   
  }

  const resetFields = () => {
    setFullName('')
    setPhone('')
    setEmail('')
    setPassword('')
  }

  return <div>
    <div className="container" id="container">
      <div className="form-container sign-in-container">
            <form action="#">
              <h1>Create Account</h1>
              <div className="social-container">
                {/* <a href="#" className="social"><i className="fab fa-facebook-f"></i></a>
                <a href="#" className="social"><i className="fab fa-google-plus-g"></i></a>
                <a href="#" className="social"><i className="fab fa-linkedin-in"></i></a> */}
              </div>
              <span>or use your email for registration</span>
              <input
          placeholder="Fullname"
          onChange={(e) => setFullName(e.target.value)}
          value={fullName}
        />
        <input
          placeholder="Phone Number"
          onChange={(e) => setPhone(e.target.value)}
          value={phone}
        />
        <input
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
          value={email}
        />
              <input
          placeholder="Password"
          type="password" 
          onChange={(e) => setPassword(e.target.value)}
          value={password}
          />
            <button onClick={onSignup}>Sign up</button>
            <p><a href="/login">Already a user? Login</a></p>
            </form>
          </div>
          <div className="overlay-container">
            <div className="overlay">
              <div className="overlay-panel overlay-left">
                <h1>Welcome Back!</h1>
                <p>To keep connected with us please login with your personal info</p>
                <button className="ghost" id="signIn">Sign In</button>
              </div>
              <div className="overlay-panel overlay-right">
                <h1>Hello, Friend!</h1>
                <p>Enter your personal details and start journey with us</p>
                <button className="ghost" id="signUp" onClick={() => window.location="/login"}>Sign In</button>
              </div>
            </div>
          </div>
      </div>      
    </div>
}

/*
1) npm i -g firebase-tools (one time only)
2) npm run build
3) firebase login (one time only)
4) firebase init (one time only)
5) firebase deploy
*/
