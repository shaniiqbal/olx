import firebase from 'firebase/app'
import 'firebase/auth'
import 'firebase/firestore'
import 'firebase/storage'

var firebaseConfig = {
  apiKey: "AIzaSyBhrzORU3e6hUFVHFhfYgTpcmDNJfMt7Rs",
  authDomain: "olxapp-ziq.firebaseapp.com",
  projectId: "olxapp-ziq",
  storageBucket: "olxapp-ziq.appspot.com",
  messagingSenderId: "561106594193",
  appId: "1:561106594193:web:7286e4eb04fd05a8765230",
  measurementId: "G-8QG8RQTXLP"
};
// Initialize Firebase
 firebase.initializeApp(firebaseConfig);

const auth = firebase.auth()
const firestore = firebase.firestore()
const storage = firebase.storage()

function register(email, password) {
  return auth.createUserWithEmailAndPassword(email, password)
}

function login(email, password) {
  return auth.signInWithEmailAndPassword(email, password)
}

function addUserToDb(user) {
  return firestore.collection('users').add(user)
}

function getAllUsers() {
  return new Promise((resolve) => {
    firestore.collection('users').get().then(snapshot => {
      const users = []
      snapshot.forEach(doc => {
        users.push({ ...doc.data(), id: doc.id })
      })
      resolve(users)
    })
  })
}

function getAllAds() {
  return new Promise((resolve) => {
    firestore.collection('ads').get().then(snapshot => {
      const ads = []
      snapshot.forEach(doc => {
        ads.push({ ...doc.data(), id: doc.id })
      })
      resolve(ads)
    })
  })
}

function getSpecificAd(adId) {
  return new Promise((resolve) => {
    firestore.collection('ads').doc(adId).get().then(doc => {
      resolve(doc.data())
    })     
  })
}

function logout(adId) {
  return auth.signOut()
}

function uploadFile(files) {
  const file = files[0];
  const ref = storage.ref(`/adsImages/${file.name}`)
  ref.put(file).then(snapshot => {
    ref.getDownloadURL().then(url => {
      console.log("URL****",url)
    })
  });
}

export {
  register,
  login,
  logout,
  addUserToDb,
  getAllUsers,
  uploadFile,
  auth,
  getAllAds,
  getSpecificAd
}

/*
1) npm install firebase
2) Create a project on firebase
3) Copy CDN configuration code from firebase project (Inside Settings)
4) 
*/