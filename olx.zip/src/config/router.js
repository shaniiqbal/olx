import React from "react"
import {
    BrowserRouter as Routers,
    Switch,
    Redirect,
    Route
} from "react-router-dom"
import HomePage from "../views/HomePage";
import Login from '../views/Login'
import SignUp from '../views/SignUp'
import Dashboard from '../views/Dashboard'
import Details from '../views/Details'
import ContactUs from '../views/ContactUs'

export default function Navigation({ user }) {
    return <Routers>
            <div>
                <Switch>
                    <Route path="/" exact>
                        {AuthChecker(!user,<HomePage />)}
                    </Route>
                    <Route path="/login" exact>
                        {AuthChecker(!user,<Login />,"/dashboard")}
                    </Route>
                     <Route path="/Signup" exact>
                        {AuthChecker(!user,<SignUp />)}
                    </Route>
                    <Route path="/contactus" exact>
                        {AuthChecker(!user,<ContactUs />)}
                    </Route>
                    <Route path="/dashboard" exact>
                        {AuthChecker(!user,<Dashboard />)}
                    </Route>
                    
                     <Route path="/dashboard/details/:adId" exact>
                        {AuthChecker(!user,<Details />)}
                    </Route>
                </Switch>
            </div>
        </Routers>
}

function AuthChecker(user, component, path="/"){
    console.log("authchecker",user, component, path);
    return user ? component : <Redirect to={path} />
}