
/*
  1) Custom Promise (ES5)
  2) Async/Await (ES6)
*/

function getPosts() {
  return new Promise((resolve, reject) => {
    fetch('https://jsonplaceholder.typicode.com/posts')
    .then(response => response.json())
    .then(json => {
      resolve(json)
    }).catch(e => {
      reject()
    })
  })
}

function getAlbums() {
  
}

export {
  getPosts,
  getAlbums
}